# p5-appelsiner-i-turbanen
Brush-up forløb af p5- og programmeringskompetencer ved starten af et nyt år med Digital Teknik
